﻿import { generateText } from "ai"
import { readFile, writeFile, mkdir } from "node:fs/promises"
import { existsSync } from "node:fs"
import path from "node:path"

const auditDir = "E:\\Account-Security-Audit"
const ledgerPath = path.join(auditDir, "account-access-ledger.csv")
const checklistPath = path.join(auditDir, "missing-evidence-checklist.md")

const today = new Date().toISOString().slice(0, 10)
const summaryPath = path.join(auditDir, `daily-summary-${today}.md`)
const warningsPath = path.join(auditDir, `redaction-warnings-${today}.md`)

await mkdir(auditDir, { recursive: true })

function safeRead(filePath, fallback = "") {
  if (!existsSync(filePath)) return fallback
  return readFile(filePath, "utf8")
}

function redact(text) {
  const warnings = []

  const patterns = [
    { name: "possible API key", regex: /\b(sk-[A-Za-z0-9_\-]{12,}|sk-proj-[A-Za-z0-9_\-]{12,})\b/g },
    { name: "possible GitHub token", regex: /\bgh[pousr]_[A-Za-z0-9_]{20,}\b/g },
    { name: "possible AWS access key", regex: /\bAKIA[0-9A-Z]{16}\b/g },
    { name: "possible bearer token", regex: /\bBearer\s+[A-Za-z0-9\-._~+/]+=*\b/g },
    { name: "possible long secret", regex: /\b[A-Za-z0-9_\-]{48,}\b/g }
  ]

  let out = text

  for (const pattern of patterns) {
    if (pattern.regex.test(out)) {
      warnings.push(`Redacted ${pattern.name}.`)
      out = out.replace(pattern.regex, "[REDACTED]")
    }
  }

  return { text: out, warnings }
}

const rawLedger = await safeRead(
  ledgerPath,
  "date,time,service,evidence_type,device_or_browser,ip_or_location_hint,source,action_taken,notes\n"
)

const rawChecklist = await safeRead(
  checklistPath,
  "# Missing Evidence Checklist\nNo checklist found yet.\n"
)

const redactedLedger = redact(rawLedger)
const redactedChecklist = redact(rawChecklist)

const prompt = `
You are my private account-access audit assistant for MVP / SKYGRID.

Analyze the sanitized evidence below.

Hard rules:
- Do not sniff network traffic.
- Do not track live location.
- Do not identify a person from IP/location alone.
- Do not request or expose passwords, API keys, session tokens, cookies, seed phrases, private keys, or MFA codes.
- Treat IP/location/device evidence as approximate.
- Use conservative reasoning.
- Do not accuse anyone.
- Focus on safe account-security actions.

Return a Markdown report with:
1. Executive summary
2. Evidence currently present
3. Evidence still missing
4. Unknown or suspicious indicators
5. Resolved/recognized indicators
6. Redaction warnings
7. Next three safest actions
8. Recommended ledger rows to add next

Sanitized CSV ledger:
${redactedLedger.text}

Sanitized missing-evidence checklist:
${redactedChecklist.text}
`

const result = await generateText({
  model: process.env.AI_GATEWAY_MODEL || "openai/gpt-4o-mini",
  prompt
})

const warnings = [
  ...redactedLedger.warnings,
  ...redactedChecklist.warnings
]

await writeFile(summaryPath, result.text + "\n", "utf8")

await writeFile(
  warningsPath,
  warnings.length
    ? warnings.map((w) => `- ${w}`).join("\n") + "\n"
    : "- No obvious secret patterns detected before analysis.\n",
  "utf8"
)

console.log(`Wrote ${summaryPath}`)
console.log(`Wrote ${warningsPath}`)
