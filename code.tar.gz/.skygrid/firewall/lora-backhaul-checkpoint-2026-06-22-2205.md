﻿# SKYGRID LoRa Backhaul Firewall Checkpoint

Status: Active
Result: LoRa/LoRaWAN gateway backhaul paths blocked inbound and outbound.

Blocked ports:
- UDP/TCP 1700
- UDP/TCP 1883
- UDP/TCP 8883
- UDP/TCP 8080
- UDP/TCP 8083

Purpose:
Defensive network-layer block for LoRa/LoRaWAN gateway backhaul traffic on this Windows host.

Important:
This does not jam or interfere with RF radio transmissions. It only blocks local network backhaul paths.

Rollback:
powershell -ExecutionPolicy Bypass -File .\scripts\skygrid-lora-backhaul-firewall.ps1 -Remove
