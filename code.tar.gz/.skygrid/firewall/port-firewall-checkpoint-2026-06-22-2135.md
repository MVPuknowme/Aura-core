﻿# SKYGRID Unified Port Firewall Checkpoint

Status: Active
Result: Inbound block rules applied successfully.

Blocked ports:
- TCP 135
- TCP 139
- TCP 445
- TCP 2179
- TCP 5040
- TCP 49664
- TCP 49665
- TCP 49666
- TCP 49667
- TCP 49668
- TCP 50265

Notes:
These are inbound Windows service / RPC / SMB / dynamic service ports. Blocking them reduces local network attack surface.

Rollback:
Get-NetFirewallRule -Group "SKYGRID Unified Port Firewall" | Remove-NetFirewallRule
